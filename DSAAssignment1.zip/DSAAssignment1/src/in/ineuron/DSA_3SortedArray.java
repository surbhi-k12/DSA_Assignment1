package in.ineuron;
import java.util.*;
public class DSA_3SortedArray {
	
	 public static int searchInsert(int[] nums, int target) {
	        int a = 0;
	        int b = 0;
	        int c = nums.length-1;
	        while(a<=c){
	            b = (a+c)/2;
	            if(nums[b]==target){
	                return b;
	            }
	            else if(nums[b]<target){
	                a = b+1;
	            }
	            else{
	                c = b-1;
	            }
	        }
	        if(target<nums[b]){
	            return b;
	        }
	        else{
	            return b+1;
	        }
	 }
	    

	public static void main(String[] args) {
	
	int[] nums= {1,3,5,6};
	int target=5;
	int result=0;
	result=searchInsert(nums,target);
	System.out.println(result);

	}

}
