package in.ineuron;
import java.util.*;
public class DSA_8Repeatition {
	
	 public static int[]  getTwoElements(int[] arr)
	  {
	int n = arr.length;
	    // sorting the array
	    Arrays.sort(arr);
	int[] res= new int[2];
	    for (int i = 0; i < n - 1; i++) {
	      if (arr[i] == arr[i + 1]) {
	        res[0] = arr[i];
	        break;
	      }
	    }
	 
	    System.out.print("and the missing element is ");
	    for (int i = 1; i <= n; i++) {
	      if (i != arr[i - 1]) {
	        res[1] = i;
	        break;
	      }
	    }
	return res;
	  }
	 
	  public static void main(String[] args)
	  {
	    int[] arr = {1,2,2,4};
	    for(int i : getTwoElements(arr)) {
	System.out.print(i+" ");
	}
	  }
	}

	


